
# D'Burger

D'burger adalah sebuah situs web yang didedikasikan untuk mengenalkan dan mempromosikan restoran makanan cepat saji bernama D'burger. Situs web ini menawarkan deskripsi yang menarik tentang berbagai hidangan dan menu yang ditawarkan oleh restoran tersebut.

Halaman beranda situs web D'burger menyajikan tampilan menarik dengan gambar makanan yang lezat untuk mengundang minat pengunjung. Desain situs web ini didominasi oleh warna-warna cerah yang mencerminkan suasana yang menyenangkan dan energik.


## Nama-nama anggota kelompok

- Fida Zafira
- Fahrul Kamal
- Habib Ahmad
- Muhammad Hadi Ryanda


## Screenshots

![img](https://drive.google.com/uc?export=view&id=1f-WfeBx46Rp-VhncCqRf-xXwMR1FGha8)

