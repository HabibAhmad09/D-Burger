@extends('layouts.main')
@section('title', 'Beranda - ')
@section('content')

@endsection
